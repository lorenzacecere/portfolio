## Ciao, sono Lorenza 👋

Sto completando la laurea magistrale in **Scienze Statistiche per le Decisioni** (LM-82)
all'Università degli Studi di Napoli Federico II.

Mi interessa quello che succede quando i metodi quantitativi incontrano un dominio
specifico: nella mia tesi lavoro su modellazione statistica applicata, e come esame a
scelta ho seguito Analisi dei segnali e dati medici, al dipartimento di Ingegneria
Biomedica.

**Attualmente cerco un tirocinio curricolare** in ambito di analisi dati e modellazione
statistica.

### Cosa uso

R (regressione e diagnostica, network analysis con igraph, text mining, Quarto e
R Markdown) · bibliometrix · VOSviewer · Gephi

### Progetti

Tre analisi complete, con codice e report leggibile:

| Progetto | Di cosa si tratta |
|---|---|
| [Carico di riscaldamento degli edifici](https://github.com/lorenzacecere/portfolio/tree/main/progetti/energy-efficiency) | Regressione multipla con diagnostica completa, inferenza robusta e validazione |
| [Eurovision 2021](https://github.com/lorenzacecere/portfolio/tree/main/progetti/eurovision-2021) | Rete del televoto e sentiment analysis dei testi |
| [Una consulenza scientifica per Spotify](https://github.com/lorenzacecere/portfolio/tree/main/progetti/spotify-bibliometria) | Analisi bibliometrica e reti citazionali |

📂 **[Vedi tutti i report online](https://lorenzacecere.github.io/portfolio/)**

### Contatti

lorenzac.analytics@gmail.com · [LinkedIn](https://linkedin.com/in/lorenza-cecere-987579325)
