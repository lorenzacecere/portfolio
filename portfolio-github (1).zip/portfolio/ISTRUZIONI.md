# Come pubblicare questo portfolio

Da leggere una volta sola. Servono circa 15 minuti.

---

## I tuoi dati sono già inseriti

Non c'è niente da modificare prima di caricare. Nei file trovi già:

- username `lorenzacecere`
- email `lorenzac.analytics@gmail.com`
- il tuo profilo LinkedIn
- nome, ateneo e anno di tutti e tre gli esami

Se qualcosa cambia in futuro, i file si modificano direttamente da GitHub: apri il file
nel repository, clicca l'icona della matita, correggi e conferma con *Commit changes*.

---

## Passo 1 — Crea l'account

Vai su [github.com](https://github.com) e registrati.

Registrati con l'username **`lorenzacecere`**: è quello che ho già inserito in tutti i
file, e comparirà nel link del CV. Se risultasse occupato, scegline un altro e dimmelo,
così aggiorno i collegamenti.

---

## Passo 2 — Crea il repository

Dalla home di GitHub, pulsante **New**.

- **Repository name:** `portfolio`
- **Public** (importante: se è privato nessuno lo vede)
- Non spuntare nulla nella sezione "Initialize this repository"
- **Create repository**

---

## Passo 3 — Carica i file

Nella pagina del repository appena creato, clicca **uploading an existing file**.

Trascina nella finestra le cartelle `docs` e `progetti` e il file `README.md`.
Il browser mantiene la struttura delle cartelle da solo.

In fondo alla pagina, scrivi qualcosa in "Commit changes" (per esempio
`Primo caricamento del portfolio`) e conferma.

---

## Passo 4 — Attiva il sito

Nel repository: **Settings** → nella barra a sinistra **Pages**.

Sotto "Build and deployment":
- **Source:** Deploy from a branch
- **Branch:** `main`, cartella `/docs`
- **Save**

Aspetta due o tre minuti. Il sito sarà a:

```
https://lorenzacecere.github.io/portfolio/
```

Questo è il link da mettere nel CV.

---

## Passo 5 — I dataset

Ci sono già tutti, nelle cartelle dei rispettivi progetti. Non devi fare niente.

---

## Passo 6 (opzionale) — La pagina del tuo profilo

GitHub mostra un testo di presentazione sul tuo profilo se crei un repository che si
chiama **esattamente come il tuo username**.

Ripeti il passo 2 con nome `lorenzacecere`, spunta "Add a README file", e incolla dentro
il contenuto di `PROFILO-GITHUB.md`.

---

## Come si aggiorna, da qui in poi

Per aggiungere un progetto nuovo:

1. Crea una cartella sotto `progetti/` con il codice e un README
2. Metti il report renderizzato in `docs/`
3. Aggiungi la voce in `docs/index.html` e in `README.md`

Tutto si può fare dall'interfaccia web di GitHub, senza installare niente. Se in futuro
lavorerai spesso sul repository, conviene imparare Git da riga di comando, ma non è
necessario adesso.

---

## Nel CV

Nella riga dei contatti, insieme a email e telefono:

```
Portfolio: lorenzacecere.github.io/portfolio
```

E nella sezione progetti, per ciascuno, due righe con il link diretto al report.
Chi legge un CV apre un link se sa già cosa ci troverà, quindi la descrizione conta
quanto il collegamento.
